<?php
// update_status.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
enforce_authenticated_session();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = (int)$_POST['order_id'];
    $user_id = get_current_user_id($pdo);

    // Pastikan order ni memang milik user yang tengah login
    $stmt = $pdo->prepare("UPDATE orders SET status = 'delivered' WHERE id = ? AND user_id = ?");
    $stmt->execute([$order_id, $user_id]);
    
    // Lepas update, redirect balik ke page tracking
    header("Location: track_order.php");
    exit();
} else {
    header("Location: track_order.php");
    exit();
}
?>