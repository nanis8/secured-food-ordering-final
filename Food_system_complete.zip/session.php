<?php
// session.php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

session_set_cookie_params([
    'lifetime' => 0,              
    'path'     => '/',
    'domain'   => '',
    'secure'   => false, // false untuk localhost
    'httponly' => true,           
    'samesite' => 'Strict'        
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function enforce_authenticated_session(): void {
    // Kalau user tak login, redirect ke login.php
    if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
        header("Location: login.php");
        exit();
    }
}

// Fungsi bantuan untuk dapatkan ID user yang sah
function get_current_user_id($pdo) {
    if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
        return (int)$_SESSION['user_id'];
    }
    if (isset($_SESSION['username'])) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$_SESSION['username']]);
        $u = $stmt->fetch();
        if ($u) {
            $_SESSION['user_id'] = (int)$u['id']; // Simpan untuk masa depan
            return (int)$u['id'];
        }
    }
    return null;
}
?>