<?php
// menu.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
enforce_authenticated_session();

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $menu_id = (int)$_POST['menu_id'];
    $qty = (int)$_POST['quantity'];
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    if (isset($_SESSION['cart'][$menu_id])) {
        $_SESSION['cart'][$menu_id] += $qty;
    } else {
        $_SESSION['cart'][$menu_id] = $qty;
    }
    header("Location: menu.php?msg=added");
    exit();
}

// Handle Search & Category Filter
$search = trim($_GET['q'] ?? '');
$category = $_GET['cat'] ?? 'All';

$query = "SELECT * FROM menus WHERE is_available = 1";
$params = [];

if ($search !== '') {
    $query .= " AND item_name LIKE ?";
    $params[] = '%' . $search . '%';
}

if ($category !== 'All') {
    $query .= " AND category = ?";
    $params[] = $category;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$menus = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; }
        body { background: #f9f9f9; }
        .navbar { display: flex; justify-content: space-between; padding: 20px 50px; background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.1); align-items: center; }
        .logo { font-size: 24px; font-weight: 900; color: #d62300; text-decoration: none; }
        .nav-links a { margin-left: 20px; text-decoration: none; font-weight: 700; color: #333; }
        .nav-links a.cart-btn { background: #d62300; color: #fff; padding: 10px 20px; border-radius: 25px; }
        .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        
        /* Search Bar Styling */
        .search-container { display: flex; gap: 10px; margin-bottom: 20px; }
        .search-input { flex: 1; padding: 15px; border: 2px solid #ddd; border-radius: 10px; font-size: 16px; outline: none; }
        .search-input:focus { border-color: #d62300; }
        .btn-search { background: #333; color: #fff; padding: 0 30px; border: none; border-radius: 10px; font-weight: 700; cursor: pointer; }

        .tabs { display: flex; gap: 15px; margin-bottom: 30px; overflow-x: auto; padding-bottom: 10px; }
        .tab { padding: 10px 25px; border-radius: 25px; text-decoration: none; color: #333; font-weight: 700; background: #fff; border: 2px solid #ddd; transition: 0.3s; white-space: nowrap; }
        .tab.active, .tab:hover { background: #d62300; color: #fff; border-color: #d62300; }
        .menu-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px; }
        .card { background: #fff; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); display: flex; flex-direction: column; }
        .card img { width: 100%; height: 200px; object-fit: cover; }
        .card-content { padding: 20px; flex: 1; display: flex; flex-direction: column; }
        .card-title { font-size: 20px; font-weight: 900; margin-bottom: 5px; }
        .card-desc { font-size: 14px; color: #666; margin-bottom: 15px; flex: 1; }
        .card-price { font-size: 22px; font-weight: 900; color: #d62300; margin-bottom: 15px; }
        .order-form { display: flex; gap: 10px; }
        .qty-input { width: 60px; padding: 10px; border: 2px solid #ddd; border-radius: 10px; text-align: center; font-weight: 700; }
        .btn-add { flex: 1; background: #d62300; color: #fff; border: none; padding: 10px; border-radius: 10px; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .btn-add:hover { background: #b51c00; }
        .no-result { text-align: center; padding: 50px; color: #999; font-size: 18px; font-weight: 700; background: #fff; border-radius: 15px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="logo">🍔 Online Food Ordering System</a>
        <div class="nav-links">
            <a href="track_order.php">Track Order</a>
            <a href="cart.php" class="cart-btn">Cart (<?= isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0 ?>)</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>
    <div class="container">
        
        <!-- SEARCH BAR (Fungsi Carian SQLi Safe) -->
        <form method="GET" class="search-container">
            <input type="text" name="q" class="search-input" placeholder="Search for burgers, fries, drinks..." value="<?= htmlspecialchars($search) ?>">
            <!-- Kekalkan kategori yang dipilih bila search -->
            <input type="hidden" name="cat" value="<?= htmlspecialchars($category) ?>">
            <button type="submit" class="btn-search">Search</button>
        </form>

        <div class="tabs">
            <?php 
            $cats = ['All', 'Burgers', 'Combos', 'Sides', 'Drinks'];
            foreach($cats as $c) {
                $active = ($category === $c) ? 'active' : '';
                // Bila tukar tab, reset search (q) supaya tunjuk semua dalam kategori tu
                echo "<a href='menu.php?cat=$c' class='tab $active'>$c</a>";
            }
            ?>
        </div>

        <?php if(isset($_GET['msg']) && $_GET['msg'] == 'added'): ?>
            <div style="background:#d1fae5; color:#065f46; padding:15px; border-radius:10px; margin-bottom:20px; font-weight:700;">Item added to cart!</div>
        <?php endif; ?>

        <div class="menu-grid">
            <?php if(count($menus) > 0): ?>
                <?php foreach($menus as $m): ?>
                <div class="card">
                    <img src="<?= htmlspecialchars($m['image_url'] ?? 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500') ?>" alt="Food">
                    <div class="card-content">
                        <div class="card-title"><?= htmlspecialchars($m['item_name']) ?></div>
                        <div class="card-desc"><?= htmlspecialchars($m['description']) ?></div>
                        <div class="card-price">RM <?= number_format((float)$m['price'], 2) ?></div>
                        <form method="POST" class="order-form">
                            <input type="hidden" name="menu_id" value="<?= $m['id'] ?>">
                            <input type="number" name="quantity" value="1" min="1" max="10" class="qty-input">
                            <button type="submit" name="add_to_cart" class="btn-add">Add to Order</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-result" style="grid-column: 1 / -1;">
                    <p>No food items found for "<?= htmlspecialchars($search) ?>".</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>