<?php
// track_order.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
date_default_timezone_set('Asia/Kuala_Lumpur');
enforce_authenticated_session();

$user_id = get_current_user_id($pdo);
if (!$user_id) {
    die("Sesi tamat. Sila log masuk semula.");
}

$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();

// --- LOGIK TIMER ---
$current_time = time();
$demo_delay_seconds = 10; // 20 saat untuk demo pantas (tukar ke 120 untuk 2 minit)

$updateStmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ? AND status = 'preparing'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Track Order</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; }
        body { background: #f9f9f9; }
        .navbar { display: flex; justify-content: space-between; padding: 20px 50px; background: #fff; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .logo { font-size: 24px; font-weight: 900; color: #d62300; text-decoration: none; }
        .container { max-width: 800px; margin: 40px auto; padding: 0 20px; }
        .box { background: #fff; border-radius: 15px; padding: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
        h2 { margin-bottom: 10px; color: #333; }
        
        /* Progress Bar */
        .progress-container { display: flex; justify-content: space-between; position: relative; margin: 40px 0; }
        .progress-container::before { content: ''; position: absolute; top: 15px; left: 0; width: 100%; height: 4px; background: #eee; z-index: 1; }
        .step { position: relative; z-index: 2; text-align: center; width: 25%; }
        .circle { width: 35px; height: 35px; background: #eee; border-radius: 50%; margin: 0 auto 10px; display: flex; justify-content: center; align-items: center; font-weight: 900; color: #fff; transition: 0.5s; }
        .step.active .circle { background: #10b981; transform: scale(1.1); }
        .step.active p { color: #10b981; font-weight: 900; }
        .step p { font-size: 13px; font-weight: 700; color: #999; }
        
        /* Butang Order Received */
        .btn-received { background: #10b981; color: white; border: none; padding: 15px 30px; border-radius: 10px; font-size: 18px; font-weight: 900; cursor: pointer; width: 100%; margin-top: 20px; display: none; transition: 0.3s;}
        .btn-received:hover { background: #059669; }

        /* Order Items */
        .order-item { display: flex; align-items: center; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 15px; }
        .order-item img { width: 70px; height: 70px; border-radius: 10px; object-fit: cover; margin-right: 15px; border: 1px solid #ddd; }
        .item-details { flex: 1; }
        .item-details h4 { margin-bottom: 5px; color: #333; }
        .item-details p { color: #666; font-size: 14px; }
        .item-price { font-weight: 900; color: #d62300; font-size: 16px; }
        
        .no-order { text-align: center; padding: 50px; }
        .btn-menu { display: inline-block; margin-top: 20px; background: #d62300; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 8px; font-weight: 700; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="menu.php" class="logo">🍔 Online Food Ordering System</a>
        <a href="logout.php" style="color:#d62300; font-weight:700; text-decoration:none;">Logout</a>
    </nav>
    
    <div class="container">
        <h1 style="margin-bottom: 20px;">Your Orders</h1>
        
        <?php if(empty($orders)): ?>
            <div class="box no-order">
                <h2 style="color:#666;">No Orders Found</h2>
                <p style="margin-top:10px; color:#999;">You haven't placed any orders yet.</p>
                <a href="menu.php" class="btn-menu">Go to Menu</a>
            </div>
        <?php else: ?>
            <?php foreach($orders as $order): ?>
                <?php 
                $order_time = strtotime($order['created_at']);
                $time_passed = $current_time - $order_time;
                $current_status = strtolower($order['status']);

                // Timer Logic
                if ($time_passed >= $demo_delay_seconds && $current_status === 'preparing') {
                    $updateStmt->execute(['delivering', $order['id']]);
                    $current_status = 'delivering';
                }

                // Progress Bar Logic
                $step2 = in_array($current_status, ['preparing', 'delivering', 'delivered']) ? 'active' : '';
                $step3 = in_array($current_status, ['delivering', 'delivered']) ? 'active' : '';
                $step4 = ($current_status === 'delivered') ? 'active' : '';
                ?>

                <div class="box">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                        <div>
                            <h2>Order #<?= $order['id'] ?></h2>
                            <p style="color:#666; margin-bottom:20px;">
                                Date: <?= date('d M Y, h:i A', $order_time) ?> <br>
                                Status: <strong style="color:#d62300;"><?= strtoupper($current_status) ?></strong>
                            </p>
                        </div>
                        <div style="font-size:24px; font-weight:900; color:#10b981;">
                            RM <?= number_format((float)$order['total_amount'], 2) ?>
                        </div>
                    </div>
                    
                    <!-- Progress Bar -->
                    <div class="progress-container">
                        <div class="step active">
                            <div class="circle">✓</div>
                            <p>Order Placed</p>
                        </div>
                        <div class="step <?= $step2 ?>">
                            <div class="circle">2</div>
                            <p>Preparing</p>
                        </div>
                        <div class="step <?= $step3 ?>">
                            <div class="circle">3</div>
                            <p>Out for Delivery</p>
                        </div>
                        <div class="step <?= $step4 ?>">
                            <div class="circle">4</div>
                            <p>Delivered</p>
                        </div>
                    </div>

                    <!-- Butang Order Received -->
                    <?php if ($current_status === 'delivering'): ?>
                        <form method="POST" action="update_status.php">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <button type="submit" class="btn-received" style="display:block;">Order Received</button>
                        </form>
                    <?php endif; ?>

                    <h3 style="margin-top:20px; margin-bottom:15px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Items Ordered</h3>
                    
                    <?php 
                    $stmtItems = $pdo->prepare("
                        SELECT m.item_name, m.image_url, oi.quantity, oi.price_at_order 
                        FROM order_items oi 
                        JOIN menus m ON oi.menu_id = m.id 
                        WHERE oi.order_id = ?
                    ");
                    $stmtItems->execute([$order['id']]);
                    $items = $stmtItems->fetchAll();
                    ?>
                    
                    <?php foreach($items as $item): ?>
                        <div class="order-item">
                            <img src="<?= htmlspecialchars($item['image_url'] ?? 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500') ?>" alt="Food">
                            <div class="item-details">
                                <h4><?= htmlspecialchars($item['item_name'] ?? 'Food Item') ?></h4>
                                <p>Qty: <?= (int)$item['quantity'] ?></p>
                            </div>
                            <div class="item-price">
                                RM <?= number_format((float)($item['price_at_order'] ?? 0) * $item['quantity'], 2) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- JAVASCRIPT AUTO REFRESH (Setiap 5 saat) -->
    <script>
        setTimeout(function(){
            window.location.reload(1);
        }, 5000);
    </script>
</body>
</html>