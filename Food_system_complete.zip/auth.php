<?php
// auth.php
declare(strict_types=1);
require_once 'session.php';

function validate_password_strength(string $password): bool {
    if (strlen($password) < 8 || strlen($password) > 128) return false;
    return true; // Ringkaskan untuk selesaikan masalah login
}

function register_user(PDO $pdo, string $username, string $email, string $password): array {
    if (empty($username) || empty($email) || empty($password)) {
        return ['success' => false, 'error' => 'Sila isi semua ruangan.'];
    }
    try {
        $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $check_stmt->execute([$username, $email]);
        if ($check_stmt->fetch()) {
            return ['success' => false, 'error' => 'Username atau emel sudah didaftarkan.'];
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $insert_stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, mfa_enabled, role) VALUES (?, ?, ?, 1, 'user')");
        $insert_stmt->execute([$username, $email, $hashed_password]);
        
        return ['success' => true, 'error' => null];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => 'Ralat pangkalan data: ' . $e->getMessage()];
    }
}