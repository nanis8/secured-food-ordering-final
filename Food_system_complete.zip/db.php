<?php
// db.php
declare(strict_types=1);

$host    = '127.0.0.1';
$db      = 'schema.sql'; // Pastikan ni sama dengan nama database kat phpMyAdmin
$user    = 'root';
$pass    = ''; 
$charset = 'utf8mb4';

// Kita tak letak port. Biar sistem cari sendiri.
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false, 
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // Tunjuk error sebenar untuk kita debug (sementara)
    die("Sambungan gagal. Error: " . $e->getMessage());
}
?>