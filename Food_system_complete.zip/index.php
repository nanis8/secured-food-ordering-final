<?php
// index.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Online Food Ordering System</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; }
        body { background: #fff; color: #333; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 50px; background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 100; }
        .logo { font-size: 24px; font-weight: 900; color: #d62300; text-decoration: none;}
        .nav-btns a { text-decoration: none; padding: 10px 20px; border-radius: 25px; font-weight: 700; margin-left: 10px; transition: 0.3s; }
        .btn-login { color: #d62300; border: 2px solid #d62300; }
        .btn-login:hover { background: #d62300; color: #fff; }
        .btn-signup { background: #d62300; color: #fff; border: 2px solid #d62300; }
        .btn-signup:hover { background: #b51c00; border-color: #b51c00; }
        
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=1600') center/cover; height: 60vh; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; color: #fff; padding: 20px; }
        .hero h1 { font-size: 50px; font-weight: 900; margin-bottom: 20px; }
        .hero p { font-size: 20px; margin-bottom: 30px; }
        .btn-hero { background: #f5ebdc; color: #d62300; padding: 15px 40px; font-size: 18px; font-weight: 900; border-radius: 30px; text-decoration: none; transition: 0.3s; }
        .btn-hero:hover { transform: scale(1.05); }
        
        .info-strip { display: flex; justify-content: center; gap: 50px; padding: 30px; background: #f5ebdc; text-align: center; font-weight: 700; font-size: 18px; flex-wrap: wrap; }
        .featured { padding: 50px; text-align: center; }
        .featured h2 { font-size: 32px; margin-bottom: 40px; }
        .menu-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; max-width: 1200px; margin: 0 auto; }
        .card { border-radius: 15px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .card img { width: 100%; height: 200px; object-fit: cover; }
        .card-body { padding: 15px; font-weight: 700; font-size: 18px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="logo">🍔 Online Food Ordering System</a>
        <div class="nav-btns">
            <?php if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true): ?>
                <a href="menu.php" class="btn-signup">Order Now</a>
                <a href="logout.php" class="btn-login">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn-login">Login</a>
                <a href="register.php" class="btn-signup">Sign Up</a>
            <?php endif; ?>
        </div>
    </nav>

    <header class="hero">
        <h1>Flame-Grilled Goodness</h1>
        <p>Delivery & Pickup available. Get your favorites today.</p>
        <a href="menu.php" class="btn-hero">Order Now</a>
    </header>

    <div class="info-strip">
        <span>🛵 Fast Delivery</span>
        <span>🛍️ Easy Pickup</span>
        <span>🔥 Freshly Made</span>
    </div>

    <section class="featured">
        <h2>Featured Menu</h2>
        <div class="menu-grid">
            <?php
            $stmt = $pdo->query("SELECT * FROM menus WHERE is_available = 1 LIMIT 4");
            while ($row = $stmt->fetch()):
            ?>
            <div class="card">
                <img src="<?= htmlspecialchars($row['image_url'] ?? 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500') ?>" alt="Food">
                <div class="card-body"><?= htmlspecialchars($row['item_name']) ?> - RM<?= number_format((float)$row['price'], 2) ?></div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
</body>
</html>