<?php
// payment.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
enforce_authenticated_session();

if (empty($_SESSION['cart'])) {
    header("Location: menu.php"); exit();
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';

// Dapatkan User ID dengan selamat
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id && isset($_SESSION['username'])) {
    // Fallback: Cari ID dari database guna username
    $stmtU = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmtU->execute([$_SESSION['username']]);
    $u = $stmtU->fetch();
    $user_id = $u ? (int)$u['id'] : null;
}

if (!$user_id) {
    die("Sesi tamat. Sila log keluar dan log masuk semula.");
}

// PROSES PEMBAYARAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_pay'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("CSRF Token Validation Failed.");
    }

    $order_type = $_POST['order_type'] ?? 'delivery';
    $address = ($order_type === 'delivery') ? trim($_POST['address']) : 'Self-Pickup at Store';
    $payment_method = $_POST['payment_method'] ?? 'FPX';

    try {
        $pdo->beginTransaction();
        
        // KIRA HARGA DI SERVER (Server-Side Integrity)
        $total_amount = 0;
        $ids = implode(',', array_keys($_SESSION['cart']));
        $stmt = $pdo->query("SELECT id, price FROM menus WHERE id IN ($ids)");
        $db_prices = [];
        while($row = $stmt->fetch()) {
            $db_prices[$row['id']] = (float)$row['price'];
        }

        foreach ($_SESSION['cart'] as $id => $qty) {
            if (isset($db_prices[$id])) {
                $total_amount += ($db_prices[$id] * $qty);
            }
        }

        // Simpan Order ke Database
        $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, delivery_address, status, payment_method) VALUES (?, ?, ?, 'preparing', ?)");
        $stmt->execute([$user_id, $total_amount, $address, $payment_method]);
        $order_id = $pdo->lastInsertId();

        // Simpan Order Items
        $stmtItem = $pdo->prepare("INSERT INTO order_items (order_id, menu_id, quantity, price_at_order) VALUES (?, ?, ?, ?)");
        foreach ($_SESSION['cart'] as $id => $qty) {
            if (isset($db_prices[$id])) {
                $stmtItem->execute([$order_id, $id, $qty, $db_prices[$id]]);
            }
        }

        $pdo->commit();
        unset($_SESSION['cart']);
        header("Location: track_order.php?success=1");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Payment failed: " . $e->getMessage();
    }
}

// Papar Semula Order Summary
$cart_items = [];
$total = 0;
$ids = implode(',', array_keys($_SESSION['cart']));
$stmt = $pdo->query("SELECT * FROM menus WHERE id IN ($ids)");
while ($row = $stmt->fetch()) {
    $qty = $_SESSION['cart'][$row['id']];
    $row['cart_qty'] = $qty;
    $row['subtotal'] = $row['price'] * $qty;
    $total += $row['subtotal'];
    $cart_items[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; }
        body { background: #f9f9f9; }
        .container { max-width: 800px; margin: 40px auto; padding: 0 20px; display: flex; gap: 20px; flex-wrap: wrap;}
        .box { background: #fff; border-radius: 15px; padding: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); flex: 1; min-width: 300px;}
        h2 { margin-bottom: 20px; color: #d62300; }
        .summary-item { display: flex; justify-content: space-between; margin-bottom: 10px; font-weight: 700; }
        .summary-item span:last-child { color: #666; }
        .total { border-top: 2px solid #eee; padding-top: 15px; margin-top: 15px; font-size: 20px; font-weight: 900; display: flex; justify-content: space-between;}
        .pay-methods label { display: block; padding: 15px; border: 2px solid #eee; border-radius: 10px; margin-bottom: 10px; cursor: pointer; font-weight: 700; display: flex; align-items: center; gap: 10px; }
        .pay-methods label:hover { border-color: #d62300; }
        .pay-methods input[type="radio"] { accent-color: #d62300; transform: scale(1.5); }
        .btn-confirm { width: 100%; background: #10b981; color: #fff; padding: 15px; border: none; border-radius: 10px; font-size: 18px; font-weight: 900; cursor: pointer; margin-top: 20px; }
        .btn-confirm:hover { background: #059669; }
        .error { background: #fee2e2; color: #b91c1c; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="box">
            <h2>Order Summary</h2>
            <?php foreach($cart_items as $item): ?>
                <div class="summary-item">
                    <span><?= htmlspecialchars($item['item_name']) ?> x<?= $item['cart_qty'] ?></span>
                    <span>RM <?= number_format((float)$item['subtotal'], 2) ?></span>
                </div>
            <?php endforeach; ?>
            <div class="total">
                <span>Total:</span>
                <span>RM <?= number_format($total, 2) ?></span>
            </div>
            <p style="margin-top:15px; font-size:13px; color:#666;"><em>Note: Final prices are securely recalculated on the server.</em></p>
        </div>
        <div class="box">
            <h2>Payment Method</h2>
            <?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="order_type" value="<?= htmlspecialchars($_POST['order_type'] ?? 'delivery') ?>">
                <input type="hidden" name="address" value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                <div class="pay-methods">
                    <label><input type="radio" name="payment_method" value="FPX" checked> Online Banking (FPX)</label>
                    <label><input type="radio" name="payment_method" value="Card"> Credit / Debit Card</label>
                    <label><input type="radio" name="payment_method" value="E-Wallet"> Touch 'n Go eWallet</label>
                </div>
                <button type="submit" name="confirm_pay" class="btn-confirm">Confirm & Pay</button>
            </form>
        </div>
    </div>
</body>
</html>