<?php
// cart.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';
enforce_authenticated_session();

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][$_GET['remove']]);
    header("Location: cart.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach($_POST['qty'] as $id => $q) {
        if ($q <= 0) unset($_SESSION['cart'][$id]);
        else $_SESSION['cart'][$id] = (int)$q;
    }
    header("Location: cart.php"); exit();
}

$cart_items = [];
$total = 0;
if (count($_SESSION['cart']) > 0) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $stmt = $pdo->query("SELECT * FROM menus WHERE id IN ($ids)");
    while ($row = $stmt->fetch()) {
        $qty = $_SESSION['cart'][$row['id']];
        $row['cart_qty'] = $qty;
        $row['subtotal'] = $row['price'] * $qty;
        $total += $row['subtotal'];
        $cart_items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; }
        body { background: #f9f9f9; }
        .navbar { display: flex; justify-content: space-between; padding: 20px 50px; background: #fff; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .logo { font-size: 24px; font-weight: 900; color: #d62300; text-decoration: none; }
        .container { max-width: 900px; margin: 40px auto; padding: 0 20px; }
        .cart-box { background: #fff; border-radius: 15px; padding: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .cart-item { display: flex; align-items: center; border-bottom: 1px solid #eee; padding: 20px 0; }
        .cart-item img { width: 80px; height: 80px; object-fit: cover; border-radius: 10px; margin-right: 20px; }
        .item-info { flex: 1; }
        .item-info h3 { font-size: 18px; margin-bottom: 5px; }
        .item-info p { color: #d62300; font-weight: 900; font-size: 18px; }
        .item-actions { display: flex; align-items: center; gap: 20px; }
        .qty-input { width: 60px; padding: 8px; border: 1px solid #ddd; border-radius: 8px; text-align: center; }
        .btn-remove { color: #ef4444; text-decoration: none; font-weight: 700; font-size: 14px; }
        .checkout-section { margin-top: 30px; border-top: 2px solid #eee; padding-top: 20px; }
        .method-toggle { display: flex; gap: 20px; margin-bottom: 20px; }
        .method-toggle label { font-weight: 700; display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .address-box { display: none; margin-bottom: 20px; }
        .address-box input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin-top: 5px; }
        .total-row { display: flex; justify-content: space-between; font-size: 24px; font-weight: 900; margin-bottom: 20px; }
        .btn-checkout { width: 100%; background: #d62300; color: #fff; padding: 15px; border: none; border-radius: 10px; font-size: 18px; font-weight: 900; cursor: pointer; }
        .btn-checkout:hover { background: #b51c00; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="menu.php" class="logo">🍔 Online Food Ordering System</a>
    </nav>
    <div class="container">
        <div class="cart-box">
            <h2 style="margin-bottom: 20px;">Your Order List</h2>
            <?php if(empty($cart_items)): ?>
                <p>Your cart is empty. <a href="menu.php" style="color:#d62300;">Go back to menu</a></p>
            <?php else: ?>
                <form method="POST">
                    <?php foreach($cart_items as $item): ?>
                    <div class="cart-item">
                        <img src="<?= htmlspecialchars($item['image_url'] ?? '') ?>" alt="Food">
                        <div class="item-info">
                            <h3><?= htmlspecialchars($item['item_name']) ?></h3>
                            <p>RM <?= number_format((float)$item['price'], 2) ?></p>
                        </div>
                        <div class="item-actions">
                            <input type="number" name="qty[<?= $item['id'] ?>]" value="<?= $item['cart_qty'] ?>" min="1" class="qty-input">
                            <a href="cart.php?remove=<?= $item['id'] ?>" class="btn-remove">Remove</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div style="margin-top: 20px;">
                        <button type="submit" name="update_cart" style="background:#333; color:#fff; padding:10px 20px; border:none; border-radius:8px; cursor:pointer;">Update Quantities</button>
                    </div>
                </form>
                <div class="checkout-section">
                    <form action="payment.php" method="POST">
                        <div class="method-toggle">
                            <label><input type="radio" name="order_type" value="delivery" checked onchange="document.getElementById('address_field').style.display='block'"> Delivery</label>
                            <label><input type="radio" name="order_type" value="pickup" onchange="document.getElementById('address_field').style.display='none'"> Pickup</label>
                        </div>
                        <div class="address-box" id="address_field">
                            <label style="font-weight:700;">Delivery Address</label>
                            <input type="text" name="address" placeholder="Enter your full address..." value="123, Jalan Ampang, KL">
                        </div>
                        <div class="total-row">
                            <span>Total:</span>
                            <span>RM <?= number_format($total, 2) ?></span>
                        </div>
                        <button type="submit" class="btn-checkout">Proceed to Payment</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>