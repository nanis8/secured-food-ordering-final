<?php
// login.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php'; 
require_once 'rate_limiter.php'; 

$loginError = '';
$msg = $_GET['msg'] ?? '';
$limiter = new RateLimiter($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip_address = $_SERVER['REMOTE_ADDR'];

    if (!empty($username) && !empty($password)) {
        if ($limiter->isLockedOut($username)) {
            $loginError = "Akaun disekat sementara kerana terlalu banyak cubaan gagal.";
        } else {
            $stmt = $pdo->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                $limiter->clearFailures($username);
                session_regenerate_id(true);
                
                $_SESSION['authenticated'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                header("Location: menu.php");
                exit();
            } else {
                $limiter->recordFailure($username, $ip_address);
                $loginError = "Username atau password tidak sah.";
            }
        }
    } else {
        $loginError = "Sila isi semua ruangan.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; font-family: 'Montserrat', sans-serif; }
        body { background: #f5ebdc; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #fff; padding: 40px; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; color: #d62300; margin-bottom: 20px; font-weight: 900;}
        input { width: 100%; padding: 12px; margin-bottom: 15px; border: 2px solid #ddd; border-radius: 8px; font-family: 'Montserrat', sans-serif;}
        button { width: 100%; padding: 12px; background: #d62300; color: #fff; border: none; border-radius: 8px; font-weight: 900; cursor: pointer; font-size: 16px;}
        button:hover { background: #b51c00; }
        .error { background: #fee2e2; color: #b91c1c; padding: 10px; border-radius: 8px; text-align: center; margin-bottom: 15px; font-size: 14px;}
        .success { background: #d1fae5; color: #065f46; padding: 10px; border-radius: 8px; text-align: center; margin-bottom: 15px; font-size: 14px;}
        .link { text-align: center; margin-top: 15px; display: block; color: #666; text-decoration: none; font-size: 14px;}
    </style>
</head>
<body>
    <div class="card">
        <h2>Log In</h2>
        <?php if($msg == 'registered'): ?><div class="success">Akaun berjaya didaftarkan! Sila login.</div><?php endif; ?>
        <?php if($loginError): ?><div class="error"><?= htmlspecialchars($loginError) ?></div><?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Sign In</button>
        </form>
        <a href="register.php" class="link">Don't have an account? Sign Up</a>
    </div>
</body>
</html>