<?php
// register.php
declare(strict_types=1);
require_once 'session.php';
require_once 'db.php';   
require_once 'auth.php'; 

$error_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm) {
        $error_message = "Kata laluan tidak sepadan.";
    } else {
        $result = register_user($pdo, $username, $email, $password);
        if ($result['success']) {
            header("Location: login.php?msg=registered");
            exit();
        } else {
            $error_message = $result['error'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; font-family: 'Montserrat', sans-serif; }
        body { background: #f5ebdc; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #fff; padding: 40px; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; color: #d62300; margin-bottom: 20px; font-weight: 900;}
        input { width: 100%; padding: 12px; margin-bottom: 15px; border: 2px solid #ddd; border-radius: 8px; font-family: 'Montserrat', sans-serif;}
        button { width: 100%; padding: 12px; background: #d62300; color: #fff; border: none; border-radius: 8px; font-weight: 900; cursor: pointer; font-size: 16px;}
        button:hover { background: #b51c00; }
        .error { background: #fee2e2; color: #b91c1c; padding: 10px; border-radius: 8px; text-align: center; margin-bottom: 15px; font-size: 14px;}
        .link { text-align: center; margin-top: 15px; display: block; color: #666; text-decoration: none; font-size: 14px;}
    </style>
</head>
<body>
    <div class="card">
        <h2>Sign Up</h2>
        <?php if($error_message): ?><div class="error"><?= htmlspecialchars($error_message) ?></div><?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Register</button>
        </form>
        <a href="login.php" class="link">Already have an account? Login</a>
    </div>
</body>
</html>